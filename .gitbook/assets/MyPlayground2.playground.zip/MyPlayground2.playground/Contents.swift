import UIKit

// MARK: 2.1. Arrays

var carMakes = [String]()

carMakes.append("Mazda")
carMakes.append("Toyota")
carMakes.append("Honda")

// Printing the current elements of the array...
print("After appending: \(carMakes)")
print("Number of elements in carMakes: \(carMakes.count)")

// Accessing a particular element from the Array...
print("The first element of carMakes: \(carMakes[0])")
print("The second element of carMakes: \(carMakes[1])")

carMakes.remove(at: 1)
// Printing the current elements of the array...
print("After removing: \(carMakes)")

// MARK: 2.2. Sets

// Creating an empty set of strings...
var colors = Set<String>()
colors.insert("black")
colors.insert("blue")
colors.insert("black")

// prints the current Set...
print(colors)

// MARK: 2.3. Tuples
// Simple tuple
var myTuple = ("Mark", 20)
// We can also define the names of the elements
var yourTuple = (name:"Julie", age:23)

//print tuples
print("myTuple: \(myTuple), yourTuple: \(yourTuple)")

// accessing tuple elements
print("yourTuple's elements:\n first element = \(yourTuple.0),\n second element = \(yourTuple.age)")

yourTuple.age = 34
// Or, yourTuple.1 = 34
print("yourTuple: \(yourTuple)")

// MARK: 2.4. Dictionaries
var carCounts = [String: Int]()

carCounts = [
    "Toyota" : 2,
    "Mazda" : 1,
    "Honda" : 10
]

//var carCounts: [String: Int] = Dictionary()
carCounts.updateValue(5, forKey: "Chevy")
print(carCounts)

carCounts.updateValue(9, forKey: "Honda")
print(carCounts)

let mazdaCount = carCounts["Mazda"]





