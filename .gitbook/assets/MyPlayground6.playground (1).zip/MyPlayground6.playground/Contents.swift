import UIKit

var greeting = "Hello, playground"

//MARK: 6.1. simple function

// function definition...
func printHelloWorld(){
    print("Hello World!")
}

//call the function
printHelloWorld()

//MARK: 6.2. function with parameters
//function definition...
func printDetails(name:String, age:Int){
    print(
        """
        The user's name is: \(name).
        The user's age is: \(age).
        \(name) is awesome!
        """
    )
}
//calling the function...
printDetails(name: "Donald", age: 25)

//MARK: 6.3. function that returns a value...

func sumOf(array:[Int]) -> Int{
    var sum = 0
    for item in array{
        sum += item
    }
    
    //returns the value...
    return sum
}

//calling the function with an integer array
print(sumOf(array: [1,2,3,4,5]))

//MARK: 6.4. two parameter labels
//function definition...
func navigate(with vehicle:String, from source:String, to destination:String) -> String{
    return "The user will use a \(vehicle) to travel from \(source) to \(destination)."
}

//calling the function
print(navigate(with: "car", from: "Boston", to: "NYC"))
