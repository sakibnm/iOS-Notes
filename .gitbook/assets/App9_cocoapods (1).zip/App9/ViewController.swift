//
//  ViewController.swift
//  App9
//
//  Created by Sakib Miazi on 5/24/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

