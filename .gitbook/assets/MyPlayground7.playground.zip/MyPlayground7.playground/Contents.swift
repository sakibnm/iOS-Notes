import UIKit

//MARK: 7.1. simple Closure...
let printHello = {
    print("Hello World!")
}

//calling closure...
printHello()

//MARK: 7.1. closures with parameters...
let sayHelloTo = { (name:String) in
    print("Hello \(name)!")
}

sayHelloTo("Donald")

//MARK: 7.2. closures with return value...
let sumOfArray = {(array:[Int]) -> Int in
    var sum = 0
    for item in array{
        sum += item
    }
    
    //returns the value...
    return sum
}

//calling the closure with an integer array
let sum = sumOfArray([1,2,3,4,5])
print(sum)


//MARK: 7.3. closures as parameters...
//defining closures...
let drive = {
    print("I am driving!")
}

let fly = {
    print("I am taking a flight!")
}

//taking a closure as the parameter 'how'
func travel(from source:String, to destination:String, how: ()->Void){
    
    print("I need to travel from \(source) to \(destination).")
    how()
}

//calling the function
travel(from: "San Francisco", to: "Boston", how: fly)

//MARK: 7.3.1. When closures accept parameters themselves and return values
//defining three closures to add, subtract, and multiply two numbers
let add = {(num1:Int, num2:Int) -> Int in
    return num1+num2
}

let subtract = {(num1:Int, num2:Int) -> Int in
    return num1-num2
}

let multiply = {(num1:Int, num2:Int) -> Int in
    return num1*num2
}

// calculate function...
func calculate(operation: (_:Int, _:Int)-> Int, num1:Int, num2:Int) -> Int{
    
    let result = operation(num1, num2)
    
    return result
}

//calling function to multiply...
print(calculate(operation: multiply, num1: 2, num2: 23))
