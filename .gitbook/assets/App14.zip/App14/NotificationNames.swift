//
//  NotificationNames.swift
//  App14
//
//  Created by Sakib Miazi on 6/15/23.
//

import Foundation

extension Notification.Name{
    static let placesFromMap = Notification.Name("placesFromMap")
}
