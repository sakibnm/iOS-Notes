//
//  Configs.swift
//  App14
//
//  Created by Sakib Miazi on 6/14/23.
//

import Foundation
class Configs{
    public static let placeIdentifier = "placeIdentifier"
}
