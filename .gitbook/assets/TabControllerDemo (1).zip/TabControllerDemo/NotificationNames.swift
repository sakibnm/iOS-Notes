//
//  NotificationNames.swift
//  TabControllerDemo
//
//  Created by Sakib Miazi on 6/12/23.
//

import Foundation

extension Notification.Name{
    static let fromRed = Notification.Name("fromRed")
    static let fromGreen = Notification.Name("fromGreen")
    static let fromBlue = Notification.Name("fromBlue")
    
}
