//
//  APIConfigs.swift
//  App11
//
//  Created by Sakib Miazi on 5/26/23.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.space:8888/contacts/json/"
}
