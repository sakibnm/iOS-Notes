import UIKit

var greeting = "Hello, playground"

greeting = "Hello, Bonobos!!!"

var count = 12

var million = 1_000_000

var multiline = """
I am a multiline String.
I might look weird, but I am really very simple.
At times I could be very useful!
"""

print(multiline)

var myNum = 12.5
print(myNum)
print(type(of: myNum))

var myFloat:Float = 13
print(myFloat)
print(type(of: myFloat))

var myString = """
My Double number is \(myNum).
My Float number is \(myFloat).
And, my multiline string is
\(multiline)
"""

print(myString)

let myConstant:Int = 14
print("My constant is \(myConstant)")

// Some code
let myName:String = "Sakib Miazi"
var myAge:Int = 10
let iUseIPhone:Bool = false


