import UIKit

//MARK: 8.1 structs...
struct Person{
    var name:String
    var age:Int
    var city:String
    
//    initializer method...
    init() {
        name = "Unknown"
        age = 18
        city = "Not Given"
    }
    
//    computed property .....
    var isMinor:Bool{
        if age < 18{
            return true
        }else{
            return false
        }
    }
    
//    method printProfile...
    
    func printProfile(){
        print(
            """
            Hi! I am \(name).
            I am \(age) years old.
            And I live in \(city)!
            Happy coding!
            """
        )
    }
}


//var newPerson:Person = Person(name: "Bob Smith", age: 30, city: "Boston")

//Creating an instance using the init()
var newPerson = Person()

//print the variable person of type Person...
print(newPerson)

//print newPerson's name...
print(newPerson.name)

//modifying the properties of newPerson...
newPerson.name = "Bob Smith"
newPerson.age = 36
newPerson.city = "Boston"

//printing newPerson after modifying the properties...
print(newPerson)

//printing the computed property...
if(newPerson.isMinor){
    print("\(newPerson.name) is a minor!")
}else{
    print("\(newPerson.name) is an adult!")
}

//printing the profile intro using the method printProfile...
newPerson.printProfile()


