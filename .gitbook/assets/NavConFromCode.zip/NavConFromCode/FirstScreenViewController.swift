//
//  ViewController.swift
//  NavConFromCode
//
//  Created by Sakib Miazi on 10/9/25.
//

import UIKit

class FirstScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        title = "My First Screen"
    }


}

