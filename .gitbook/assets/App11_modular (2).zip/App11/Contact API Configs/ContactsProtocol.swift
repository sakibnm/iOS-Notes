//
//  ContactsProtocol.swift
//  App11
//
//  Created by Sakib Miazi on 5/29/23.
//

import Foundation

protocol ContactsProtocol{
    func getAllContacts()
    func addANewContact(contact: Contact)
    func getContactDetails(name: String)
}
