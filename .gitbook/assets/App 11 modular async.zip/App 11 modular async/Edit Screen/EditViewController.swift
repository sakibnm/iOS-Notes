//
//  EditViewController.swift
//  App11
//
//  Created by Sakib Miazi on 10/21/25.
//

import UIKit

class EditViewController: UIViewController {
    
    let editView = EditScreenView()
    
    let notificationCenter = NotificationCenter.default
    
    var contact: Contact!
    
    var currentContactName: String = ""
    
    override func loadView() {
        view = editView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        currentContactName = contact.name
        loadForm(contact)
        
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveButtonTapped))
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelButtonTapped))
        navigationItem.leftBarButtonItem = cancelButton
        navigationItem.rightBarButtonItem = saveButton
    }
    
    func loadForm(_ contact: Contact) {
        editView.textFieldEditName.text = contact.name
        editView.textFieldEditPhone.text = "\(contact.phone)"
        editView.textFieldEditEmail.text = contact.email
    }
    
    @objc func saveButtonTapped() {
        if let name = editView.textFieldEditName.text,
           let phoneText = editView.textFieldEditPhone.text,
           let phone = Int(phoneText),
           let email = editView.textFieldEditEmail.text {
            let newContact = Contact(name: name, email: email, phone: phone)
            notificationCenter.post(name: NSNotification.Name(rawValue: "edited"), object: (newContact, currentContactName))
        }
        
    }
    
    @objc func cancelButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
}
