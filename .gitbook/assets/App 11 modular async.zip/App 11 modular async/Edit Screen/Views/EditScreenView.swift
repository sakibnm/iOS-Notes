//
//  EditScreenView.swift
//  App11
//
//  Created by Sakib Miazi on 10/21/25.
//

import UIKit

class EditScreenView: UIView {

    var textFieldEditName:UITextField!
    var textFieldEditEmail:UITextField!
    var textFieldEditPhone:UITextField!

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .systemBackground
        
        setupTextFieldEditName()
        setupTextFieldEditEmail()
        setupTextFieldEditPhone()
        initConstraints()
    }
    
    func setupTextFieldEditName(){
        textFieldEditName = UITextField()
        textFieldEditName.borderStyle = .roundedRect
        textFieldEditName.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldEditName)
    }
    
    func setupTextFieldEditEmail(){
        textFieldEditEmail = UITextField()
        textFieldEditEmail.borderStyle = .roundedRect
        textFieldEditEmail.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldEditEmail)
    }
    
    func setupTextFieldEditPhone(){
        textFieldEditPhone = UITextField()
        textFieldEditPhone.borderStyle = .roundedRect
        textFieldEditPhone.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldEditPhone)
    }
    
    func initConstraints(){
        NSLayoutConstraint.activate([
            textFieldEditName.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor, constant: 16),
            textFieldEditName.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 4),
            textFieldEditName.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -4),
            
            textFieldEditEmail.topAnchor.constraint(equalTo: textFieldEditName.bottomAnchor, constant: 16),
            textFieldEditEmail.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 4),
            textFieldEditEmail.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -4),
            
            textFieldEditPhone.topAnchor.constraint(equalTo: textFieldEditEmail.bottomAnchor, constant: 16),
            textFieldEditPhone.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 4),
            textFieldEditPhone.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -4),
        ])
        
        
        
    }
    
    //MARK: initializing constraints...
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
