//
//  ViewController.swift
//  App11
//
//  Created by Sakib Miazi on 5/26/23.
//

import UIKit
import Alamofire

class ContactsViewController: UIViewController {
    
    //MARK: list to display the contact names in the TableView...
    var contactNames = [String]()
    
    let notificationCenter = NotificationCenter.default
    
    let mainScreen = MainScreenView()
    
    override func loadView() {
        view = mainScreen
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Contacts JSON API"
        
        //MARK: setting the delegate and data source...
        mainScreen.tableViewContacts.dataSource = self
        mainScreen.tableViewContacts.delegate = self
        //MARK: removing the separator line...
        mainScreen.tableViewContacts.separatorStyle = .none
        
        //MARK: add action to Add Contact button...
        mainScreen.buttonAdd.addTarget(self, action: #selector(onButtonAddTapped), for: .touchUpInside)
        
        //MARK: get all contact names when the main screen loads...
        callGetAllContacts()
        
        notificationCenter.addObserver(
            self,
            selector: #selector(editContactSaveButtonPressed(notification:)),
            name: NSNotification.Name("edited"),
            object: nil)
    }
    
    @objc func onButtonAddTapped(){
        //do the validations...
        if let name = mainScreen.textFieldAddName.text,
           let email = mainScreen.textFieldAddEmail.text,
           let phoneText = mainScreen.textFieldAddPhone.text{
            
            if let phone = Int(phoneText){
                //The String 'phoneText' is successfully converted to an Int...
                let contact = Contact(name: name, email: email, phone: phone)
                print(contact)
                callAddNewContact(contact: contact)
            }else{
                showErrorAlert(message: "Phone number is not valid!")
            }
        }
        else{
            showErrorAlert(message: "Check the formats of email, name, or phone number!")
        }
    }
    
    
    func callGetAllContacts(){
        Task{
            let getallSuccess = try await getAllContacts()
            if getallSuccess{
                mainScreen.tableViewContacts.reloadData()
            }
        }
    }
    
    func callforDetailsOfContact(named: String){
        Task{
            if let contact = try await getContactDetails(name: named){
                showDetailsInAlert(data: contact)
            }else{
                showErrorAlert(message: "Error occurred while loading contact!")
            }
        }
    }
    
    func callAddNewContact(contact: Contact){
        Task{
            let addSuccess = try await addANewContact(contact: contact)
            if addSuccess{
                self.clearAddForms()
                self.callGetAllContacts()
            }
        }
    }
    
    func editContactPressed(for contactName: String){
        Task{
            let contact = try await getContactDetails(name: contactName)
            if let contact = contact{
                let vc = EditViewController()
                vc.contact = contact
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
   
    
    @objc func editContactSaveButtonPressed(notification: Notification){
        let tuple: (Contact, String) = notification.object as! (Contact, String)
        Task{
            let deleteSuccess = try await deleteContact(name: tuple.1)
            if deleteSuccess{
                let addSuccess = try await addANewContact(contact: tuple.0)
                if addSuccess{
                    self.navigationController?.popViewController(animated: true)
                    self.callGetAllContacts()
                }
            }
        }
    }
    
    func deleteContactPressed(for contactName: String){
        let alert = UIAlertController(title: "Delete Contact", message: "Are you sure you want to delete \(contactName)?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive){_ in
            Task{
                let deleteSuccess = try await self.deleteContact(name: contactName)
                if deleteSuccess{
                    self.callGetAllContacts()
                }
            }
        })
        present(alert, animated: true)
        
    }
    
    
    
    func clearAddForms(){
        mainScreen.textFieldAddName.text = ""
        mainScreen.textFieldAddEmail.text = ""
        mainScreen.textFieldAddPhone.text = ""
    }
    
    func showDetailsInAlert(data: Contact){
        //MARK: show alert...
        let message = """
            name: \(data.name)
            email: \(data.email)
            phone: \(data.phone)
            """
        let alert = UIAlertController(title: "Selected Contact", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
        
    }
    
    func showErrorAlert(message: String){
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
    
    
    
    
}



