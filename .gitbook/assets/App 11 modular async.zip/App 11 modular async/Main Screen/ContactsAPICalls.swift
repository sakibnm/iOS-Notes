//
//  ContactsAPICalls.swift
//  App11
//
//  Created by Sakib Miazi on 5/29/23.
//

import Foundation
import UIKit
import Alamofire

extension ContactsViewController:ContactsProtocol{
    
    //MARK: get all contacts...
    func getAllContacts() async -> Bool{
        if let url = URL(string: APIConfigs.baseURL + "getall") {
            
            let response = await AF.request(url, method: .get)
                .serializingData()
                .response
            
            let statusCode = response.response?.statusCode
            
            switch response.result {
            case .success(let data):
                if let uwStatusCode = statusCode {
                    switch uwStatusCode {
                    case 200...299:
                        //MARK: the request was valid 200-level...
                        self.contactNames.removeAll()
                        let decoder = JSONDecoder()
                        do {
                            let receivedData = try decoder.decode(ContactNames.self, from: data)
                            for item in receivedData.contacts {
                                self.contactNames.append(item.name)
                            }
                            return true
                        } catch {
                            print("JSON couldn't be decoded.")
                            return false
                        }
                        
                    case 400...499:
                        //MARK: the request was not valid 400-level...
                        print(data)
                        return false
                        
                    default:
                        //MARK: probably a 500-level error...
                        print(data)
                        return false
                    }
                }
                
            case .failure(let error):
                //MARK: there was a network error...
                print(error)
                return false
            }
        } else {
            return false
        }
        return false
    }
    
    //MARK: get details of a contact...
    func getContactDetails(name: String) async -> Contact?{
        var contact:Contact?
        
        if let url = URL(string: APIConfigs.baseURL + "details") {
            
            let response = await AF.request(url, method: .get, parameters: ["name": name])
                .serializingData()
                .response
            
            let statusCode = response.response?.statusCode
            
            switch response.result {
            case .success(let data):
                if let uwStatusCode = statusCode {
                    switch uwStatusCode {
                    case 200...299:
                        let decoder = JSONDecoder()
                        contact = try? decoder.decode(Contact.self, from: data)
                        return contact
                        
                    case 400...499:
                        //MARK: the request was not valid 400-level...
                        print(data)
                        return nil
                        
                    default:
                        //MARK: probably a 500-level error...
                        print(data)
                        return nil
                    }
                }
                
            case .failure(let error):
                //MARK: there was a network error...
                print(error)
                return nil
            }
        } else {
            return nil
        }
        return contact
    }
    
    //MARK: add a new contact call: add endpoint...
    func addANewContact(contact: Contact) async -> Bool{
        if let url = URL(string: APIConfigs.baseURL + "add") {
            
            let response = await AF.request(
                url,
                method: .post,
                parameters: [
                    "name": contact.name,
                    "email": contact.email,
                    "phone": contact.phone
                ]
            )
            .serializingData()
            .response
            
            let statusCode = response.response?.statusCode
            
            switch response.result {
            case .success(let data):
                if let uwStatusCode = statusCode {
                    switch uwStatusCode {
                    case 200...299:
                        return true
                        
                    case 400...499:
                        return false
                        
                    default:
                        return false
                    }
                }
                return false
                
            case .failure(_):
                return false
            }
        } else {
            return false
        }
    }
    
    //MARK: delete the selected contact...
    func deleteContact(name: String) async -> Bool{
        
        if let url = URL(string: APIConfigs.baseURL + "delete") {
            
            let response = await AF.request(
                url,
                method: .get,
                parameters: ["name": name]
            )
            .serializingData()
            .response
            
            let statusCode = response.response?.statusCode
            
            switch response.result {
            case .success(let data):
                if let uwStatusCode = statusCode {
                    switch uwStatusCode {
                    case 200...299:
                        return true
                        
                    case 400...499:
                        return false
                        
                    default:
                        return false
                    }
                }
                return false
                
            case .failure(_):
                return false
            }
        } else {
            return false
        }
    }
}
