//
//  ContactListTableViewManager.swift
//  App11
//
//  Created by Sakib Miazi on 10/21/25.
//

import UIKit

extension ContactsViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "names", for: indexPath) as! ContactsTableViewCell
        cell.labelName.text = contactNames[indexPath.row]
        
        //MARK: crating an accessory button...
        let buttonOptions = UIButton(type: .system)
        buttonOptions.sizeToFit()
        buttonOptions.showsMenuAsPrimaryAction = true
        //MARK: setting an icon from sf symbols...
        buttonOptions.setImage(UIImage(systemName: "slider.horizontal.3"), for: .normal)
        
        //MARK: setting up menu for button options click...
        buttonOptions.menu = UIMenu(title: "Edit/Delete?",
                                    children: [
                                        UIAction(title: "Edit",handler: {(_) in
                                            self.editContactPressed(for: self.contactNames[indexPath.row])
                                        }),
                                        UIAction(title: "Delete",handler: {(_) in
                                            self.deleteContactPressed(for: self.contactNames[indexPath.row])
                                        })
                                    ])
        //MARK: setting the button as an accessory of the cell...
        cell.accessoryView = buttonOptions
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.callforDetailsOfContact(named: self.contactNames[indexPath.row])
    }
}
