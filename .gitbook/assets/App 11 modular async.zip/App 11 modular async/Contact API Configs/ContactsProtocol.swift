//
//  ContactsProtocol.swift
//  App11
//
//  Created by Sakib Miazi on 5/29/23.
//

import Foundation

protocol ContactsProtocol{
    func getAllContacts() async -> Bool
    func addANewContact(contact: Contact) async -> Bool
    func getContactDetails(name: String) async -> Contact?
    func deleteContact(name: String) async -> Bool
}
