//
//  Configs.swift
//  App12
//
//  Created by Sakib Miazi on 6/2/23.
//

import Foundation
class Configs{
    static let tableViewContactsID = "tableViewContactsID"
}
