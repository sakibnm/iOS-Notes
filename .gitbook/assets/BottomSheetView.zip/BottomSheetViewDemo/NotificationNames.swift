//
//  NotificationNames.swift
//  BottomSheetViewDemo
//
//  Created by Sakib Miazi on 6/13/23.
//

import Foundation
extension Notification.Name{
    static let nameSelected = Notification.Name("nameSelected")
}
