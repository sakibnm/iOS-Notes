//
//  Configs.swift
//  BottomSheetViewDemo
//
//  Created by Sakib Miazi on 6/13/23.
//

import Foundation
class Configs{
    static let searchTableViewID = "searchTableViewID"
}
