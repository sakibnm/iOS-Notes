//
//  NotificationNames.swift
//  App7
//
//  Created by Sakib Miazi on 5/22/23.
//

import Foundation
extension Notification.Name{
    static let textFromScondScreen = Notification.Name("textFromSecondScreen")
}
