import UIKit

//MARK: 5.1. for loops...
let range = 1...10

for number in range{
    print(number)
}

var carMakesSecond = ["Toyota", "Honda", "Mazda", "Chevy"]

for item in carMakesSecond{
    print(item)
}

//underscore...
for _ in 1...10{
    print("Doing the task!")
}

//MARK: 5.2. While loops....
var targetNum = 1
while targetNum <= 50{
    print(targetNum)
    targetNum += 1
}

//MARK: 5.3. Repeat loop...
var myNum = 1

repeat{
    print(myNum)
    myNum += 1
} while myNum <= 50

//MARK: 5.4. break

let breakPoint = 4
var countDown = 1
while breakPoint >= 0 {
    print("I will run!")
    
//  activating break point
    if countDown == breakPoint{
        print("I am tired now!")
        break
    }
    countDown += 1
}

//MARK: 5.4. continue

for number in 1...10 {
    //skipping the even numbers
    if number%2 == 0{
        continue
    }
    
    print("This an odd number:\(number)")
}
