import UIKit

//MARK: 3.1. Arithmetic Operators

let num1 = 5
let num2 = 33

//Addition...
let sum = num1 + num2

//Subtraction...
let difference = num2 - num1

//Multiplication...
let product = num1 * num2

//Division (and remainder)...
let divided = num2 / num1
let remainder = num2 % num1

print(
    """
    Results:
    Sum = \(sum)
    Difference = \(difference)
    Product = \(product)
    Division result = \(divided)
    Division remainder = \(remainder)
    """
)

//Caveats...
//let myInt:Int = 20
//let myDouble:Double = 30.5
//
//let sum:Int = myInt + myDouble

// MARK: 3.2. Operator Overloading...
let firstName = "Sakib"
let lastName = "Miazi"
let fullName = firstName + " " + lastName
print(fullName)

let listNumOne = [1,2,3]
let listNumTwo = [4,5,6]
let listNum = listNumOne + listNumTwo
print(listNum)
 
//let listOne = [1,2,3]
//let listTwo = ["four", "five"]
//let listOneTwo = listOne + listTwo

//MARK: 3.3. More on Operators
//Increment...
var count = 0
count += 1
// count = 1

//Multiply...
var number = 5
number *= 4
// number = 20

//Divide...
var number2 = 10
number2 /= 2
// number2 = 5

//String operations...
var name = "Mark"
var surname = "Webber"
name += surname
// name = "Mark Webber"

//MARK: 3.4. Comparison operators and Booleans...
// Comparison operators and Booleans...
let a = 10
let b = 12

let isEqual = a == b

print(isEqual)
print(type(of: isEqual))
