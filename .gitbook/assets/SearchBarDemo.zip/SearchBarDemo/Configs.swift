//
//  Configs.swift
//  SearchBarDemo
//
//  Created by Sakib Miazi on 6/12/23.
//

import Foundation
class Configs{
    static let searchTableViewID = "searchTableViewID"
}
