//
//  Configs.swift
//  App10
//
//  Created by Sakib Miazi on 5/25/23.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.space:8888/contacts/text/"
}
