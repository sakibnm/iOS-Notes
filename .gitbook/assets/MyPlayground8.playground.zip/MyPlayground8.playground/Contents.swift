import UIKit

var myInt:Int?
//assigning a value...
myInt = 10

//optional binding it with if-let...
if let unwrappedMyInt = myInt{
    //value present
    print(unwrappedMyInt)
}else{
    // handling nil
    print("Optional value myInt must be initialized!")
}

//forced unwrapping...
print(myInt!)

//print(myInt)
